# Làng Lá Auto v0.5.0 — Android source

Target game: Huyền Thoại Làng Lá (`com.huyenthoailangla.gg`)
Target test device: Motorola moto g57 power, Android 16.
Reference screenshot size supplied by user: 2400 x 1080.

## What this version adds

- Three separately saved, user-authored sequences: daily tasks, stage runs, and reward collection.
- Each step stores the expected recognized screen label and an X/Y tap coordinate.
- A sequence takes a fresh screenshot before every tap, hides the overlay during capture, and proceeds only if the recognizer returns the exact expected screen label.
- Captures whose dimensions are not exactly 2400 x 1080 are rejected before a tap.
- A failed root tap, unknown screen, or mismatched screen stops the sequence. Maximum 50 steps per sequence.
- Emergency stop cancels the active sequence.
- The overlay panel is focusable so its coordinate fields can open the keyboard.

## Important limitations

This is not a preconfigured game bot. The screenshots do not provide verified tap coordinates or a proven game-state transition graph. Therefore no coordinates are guessed or shipped. The user must inspect the live game and enter the correct expected screen label and pixel coordinate for each step. The 14-image color fingerprint matcher is approximate and can fail when the game has animations, popups, changed UI, or different rendering. Do not use this for paid purchases, spending premium currency, consuming rare items, or irreversible account actions. Test one step at a time first.

The app has not been built or run on a physical device in this environment. The ZIP is source code, not an installable APK.

## How to configure

1. Build and install the Android project. Grant overlay permission and approve `su` access.
2. Open the game in landscape mode. Confirm the screenshot is 2400 x 1080.
3. Open the LL bubble and press **CHỤP & NHẬN DIỆN**.
4. Enter the exact recognized screen name in the screen field. Examples: `Trang chủ`, `Nhiệm vụ ngày`, `Bản đồ Khiêu chiến`, `Thông tin ải`, `Đội hình`, `Nhận thưởng`.
5. Enter the pixel X and Y for one safe button. X is 0–2399; Y is 0–1079.
6. Add that step to the relevant sequence: daily, stage, or reward.
7. Repeat for each transition, checking the screen label and coordinates at every stage. The sequence order is the order in which steps are added.
8. Run only one sequence at a time. Watch the game during initial tests. Use **DỪNG KHẨN CẤP** if anything unexpected happens.

A task sequence does not infer what button to press. It follows only the steps you explicitly recorded. If a screen does not match the expected label, the sequence stops without tapping.

## Build

Open this folder in Android Studio with Android Gradle Plugin 8.7.3 and a compatible Gradle 8.x installation. Build the `app` debug variant. No Gradle wrapper is included in this source ZIP.
