plugins { id("com.android.application") }

android {
    namespace = "vn.langla.auto"
    compileSdk = 35
    defaultConfig {
        applicationId = "vn.langla.auto"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.5.0"
    }
}
