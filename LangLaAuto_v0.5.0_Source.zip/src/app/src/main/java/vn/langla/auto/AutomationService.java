package vn.langla.auto;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.File;

public class AutomationService extends Service {
    public static final String ACTION_START="vn.langla.auto.START", ACTION_STOP="vn.langla.auto.STOP";
    private static final String CHANNEL="langla_auto";
    private WindowManager wm; private View bubble,panel; private boolean stopped=true;
    private TextView result; private EditText targetX,targetY,expected; private String lastRecognition=""; private Handler handler=new Handler(Looper.getMainLooper());
    private TaskEngine taskEngine; private boolean taskRunning=false; private java.util.List<TaskEngine.Step> activeSteps; private int activeIndex=0; private String activeTask="";
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);taskEngine=new TaskEngine(this);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_STOP.equals(intent.getAction())){stopEngine();stopSelf();return START_NOT_STICKY;}
        if(intent!=null && ACTION_START.equals(intent.getAction())){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Làng Lá Auto",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
            Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("Làng Lá Auto")
                .setContentText("Bong bóng điều khiển đang hoạt động").setSmallIcon(android.R.drawable.ic_media_play).build();
            startForeground(7,n); stopped=false; showBubble();
        }
        return START_NOT_STICKY;
    }
    private WindowManager.LayoutParams params(int w,int h,int gravity){
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
    }
    private void showBubble(){
        if(!Settings.canDrawOverlays(this))return;
        if(bubble!=null)return;
        TextView b=new TextView(this); b.setText("LL");b.setTextColor(Color.WHITE);b.setTextSize(17);b.setGravity(Gravity.CENTER);
        GradientDrawable bg=new GradientDrawable();bg.setColor(Color.rgb(30,115,210));bg.setShape(GradientDrawable.OVAL);bg.setStroke(3,Color.WHITE);b.setBackground(bg);
        WindowManager.LayoutParams p=params(dp(54),dp(54),Gravity.TOP|Gravity.START);p.x=0;p.y=dp(180);
        b.setOnClickListener(v->togglePanel());
        b.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;long down;
            public boolean onTouch(View v,MotionEvent e){
                if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;down=System.currentTimeMillis();return true;}
                if(e.getAction()==MotionEvent.ACTION_MOVE){p.x=ox+(int)(e.getRawX()-sx);p.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(b,p);return true;}
                if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-sx)<12&&Math.abs(e.getRawY()-sy)<12)togglePanel();return true;}return true;
            }});
        bubble=b;wm.addView(bubble,p);
    }
    private void togglePanel(){if(panel!=null){wm.removeView(panel);panel=null;return;} showPanel();}
    private TextView line(LinearLayout box,String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(dp(8),dp(7),dp(8),dp(7));box.addView(t);return t;}
    private void action(LinearLayout box,String text,Runnable r){Button b=new Button(this);b.setText(text);b.setOnClickListener(v->r.run());box.addView(b,new LinearLayout.LayoutParams(-1,-2));}
    private void showPanel(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(10),dp(12),dp(10));box.setBackgroundColor(Color.rgb(28,34,45));
        line(box,"LÀNG LÁ AUTO · v0.5.0",18);line(box,"Chuỗi tác vụ do bạn tự cấu hình; mỗi bước đều phải khớp màn hình.",12);
        result=line(box,"Màn hình: chưa kiểm tra",13);
        action(box,"CHỤP & NHẬN DIỆN",()->captureAndRecognize());
        line(box,"CẤU HÌNH BƯỚC (tọa độ pixel theo ảnh màn hình)",13);
        expected=new EditText(this);expected.setSingleLine(true);expected.setHint("Màn hình cần khớp, ví dụ: Trang chủ");expected.setTextColor(Color.WHITE);expected.setHintTextColor(Color.LTGRAY);box.addView(expected);
        LinearLayout coords=new LinearLayout(this);coords.setOrientation(LinearLayout.HORIZONTAL);
        targetX=new EditText(this);targetX.setSingleLine(true);targetX.setInputType(2);targetX.setHint("X pixel");targetX.setTextColor(Color.WHITE);coords.addView(targetX,new LinearLayout.LayoutParams(0,-2,1));
        targetY=new EditText(this);targetY.setSingleLine(true);targetY.setInputType(2);targetY.setHint("Y pixel");targetY.setTextColor(Color.WHITE);coords.addView(targetY,new LinearLayout.LayoutParams(0,-2,1));box.addView(coords);
        action(box,"LƯU BƯỚC VÀO NHIỆM VỤ NGÀY",()->addTaskStep(TaskEngine.DAILY));
        action(box,"LƯU BƯỚC VÀO ĐI ẢI",()->addTaskStep(TaskEngine.STAGE));
        action(box,"LƯU BƯỚC VÀO NHẬN THƯỞNG",()->addTaskStep(TaskEngine.REWARD));
        action(box,"CHẠY CHUỖI NHIỆM VỤ NGÀY",()->startTask(TaskEngine.DAILY));
        action(box,"CHẠY CHUỖI ĐI ẢI",()->startTask(TaskEngine.STAGE));
        action(box,"CHẠY CHUỖI NHẬN THƯỞNG",()->startTask(TaskEngine.REWARD));
        action(box,"XÓA CẤU HÌNH NHIỆM VỤ NGÀY",()->clearTask(TaskEngine.DAILY));
        action(box,"XÓA CẤU HÌNH ĐI ẢI",()->clearTask(TaskEngine.STAGE));
        action(box,"XÓA CẤU HÌNH NHẬN THƯỞNG",()->clearTask(TaskEngine.REWARD));
        action(box,"CHẠY 1 BƯỚC ĐÃ LƯU (CŨ)",()->runSavedStep());
        action(box,"KIỂM TRA ROOT",()->new Thread(()->{
            boolean ok=RootShell.check();handler.post(()->{if(result!=null)result.setText(ok?"Root: uid=0 (đã cấp)":"Root: chưa được cấp quyền su");});
        }).start());
        action(box,"DỪNG KHẨN CẤP",()->{taskRunning=false;stopped=true;result.setText("Đã dừng mọi tác vụ.");});
        action(box,"ĐÓNG BẢNG",()->togglePanel());
        ScrollView sc=new ScrollView(this);sc.addView(box);panel=sc;
        WindowManager.LayoutParams p=params(dp(285),-2,Gravity.TOP|Gravity.END);p.flags=WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL; p.x=dp(8);p.y=dp(100);wm.addView(panel,p);
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void captureAndRecognize(){
        result.setText("Đang chụp (tạm ẩn bảng điều khiển)…");
        // Prevent overlay UI from polluting the screenshot used for matching.
        if(panel!=null)panel.setVisibility(View.INVISIBLE);
        if(bubble!=null)bubble.setVisibility(View.INVISIBLE);
        handler.postDelayed(()->new Thread(()->{
            String path=RootShell.capturePath();String text="Không chụp được ảnh (kiểm tra quyền root).";
            if(path!=null){Bitmap bm=BitmapFactory.decodeFile(path);text=new ScreenRecognizer(this).recognize(bm);if(bm!=null)bm.recycle();}
            final String out=text;handler.post(()->{
                lastRecognition=out;
                if(bubble!=null)bubble.setVisibility(View.VISIBLE);
                if(panel!=null)panel.setVisibility(View.VISIBLE);
                if(result!=null)result.setText("Màn hình: "+out);
            });
        }).start(),350);
    }
    private void addTaskStep(String task){
        if(expected==null||targetX==null||targetY==null)return;
        String label=expected.getText().toString().trim();
        try{int x=Integer.parseInt(targetX.getText().toString().trim());int y=Integer.parseInt(targetY.getText().toString().trim());
            if(label.isEmpty()||x<0||x>=2400||y<0||y>=1080){result.setText("Với ảnh 2400x1080, X phải 0–2399 và Y phải 0–1079.");return;}
            if(taskEngine.add(task,label,x,y)){result.setText("Đã thêm bước vào "+TaskEngine.title(task)+". Tổng bước: "+taskEngine.get(task).size());}
            else result.setText("Không lưu được bước.");
        }catch(Exception e){result.setText("Nhập tọa độ X/Y dạng số nguyên.");}
    }
    private void clearTask(String task){taskRunning=false;taskEngine.clear(task);result.setText("Đã xóa chuỗi "+TaskEngine.title(task)+".");}
    private void startTask(String task){
        if(stopped){result.setText("Hãy bật tool trước.");return;}
        if(taskRunning){result.setText("Đang có chuỗi chạy. Hãy dừng trước khi chạy chuỗi khác.");return;}
        activeSteps=taskEngine.get(task);if(activeSteps.isEmpty()){result.setText("Chưa có bước. Chụp màn hình, nhập tên màn hình + tọa độ rồi lưu vào chuỗi.");return;}
        activeTask=task;activeIndex=0;taskRunning=true;result.setText("Bắt đầu chuỗi "+TaskEngine.title(task)+" · "+activeSteps.size()+" bước.");runTaskStep();
    }
    private void runTaskStep(){
        if(!taskRunning||stopped)return;
        if(activeIndex>=activeSteps.size()){taskRunning=false;if(result!=null)result.setText("Hoàn tất chuỗi "+TaskEngine.title(activeTask)+". Hãy kiểm tra trạng thái game.");return;}
        TaskEngine.Step step=activeSteps.get(activeIndex);
        if(panel!=null)panel.setVisibility(View.INVISIBLE);if(bubble!=null)bubble.setVisibility(View.INVISIBLE);
        handler.postDelayed(()->new Thread(()->{
            String path=RootShell.capturePath();Bitmap bm=path==null?null:BitmapFactory.decodeFile(path);
            String found=(bm!=null && (bm.getWidth()!=2400 || bm.getHeight()!=1080))?"Sai độ phân giải ảnh: "+(bm==null?"không có ảnh":bm.getWidth()+"x"+bm.getHeight()):new ScreenRecognizer(this).recognize(bm);if(bm!=null)bm.recycle();
            final String detected=found;handler.post(()->{
                if(bubble!=null)bubble.setVisibility(View.VISIBLE);if(panel!=null)panel.setVisibility(View.VISIBLE);
                if(!taskRunning||stopped)return;
                lastRecognition=detected;
                boolean match=detected.equals(step.screen)||detected.startsWith(step.screen+" (" );
                if(!match){taskRunning=false;if(result!=null)result.setText("ĐÃ TẠM DỪNG: bước "+(activeIndex+1)+" cần ["+step.screen+"] nhưng nhận diện ["+detected+"]. Không chạm.");return;}
                if(result!=null)result.setText("Bước "+(activeIndex+1)+"/"+activeSteps.size()+": "+step.screen+" · đang chạm");
                new Thread(()->{boolean ok=RootShell.tap(step.x,step.y);handler.post(()->{
                    if(!taskRunning||stopped)return;if(!ok){taskRunning=false;if(result!=null)result.setText("Lệnh chạm thất bại. Đã dừng.");return;}
                    activeIndex++;handler.postDelayed(()->runTaskStep(),step.waitMs);
                });}).start();
            });
        }).start(),350);
    }
    private void saveStep(){
        if(expected==null||targetX==null||targetY==null)return;
        String label=expected.getText().toString().trim();
        try{
            int x=Integer.parseInt(targetX.getText().toString().trim());
            int y=Integer.parseInt(targetY.getText().toString().trim());
            if(label.isEmpty()||x<0||y<0){result.setText("Nhập tên màn hình và tọa độ hợp lệ.");return;}
            getSharedPreferences("steps",MODE_PRIVATE).edit().putString("label",label).putInt("x",x).putInt("y",y).apply();
            result.setText("Đã lưu bước: "+label+" → ("+x+","+y+")");
        }catch(Exception e){result.setText("Tọa độ phải là số nguyên pixel.");}
    }
    private void runSavedStep(){
        if(stopped){result.setText("Tool đang dừng.");return;}
        android.content.SharedPreferences p=getSharedPreferences("steps",MODE_PRIVATE);
        String label=p.getString("label","");int x=p.getInt("x",-1),y=p.getInt("y",-1);
        if(label.isEmpty()||x<0||y<0){result.setText("Chưa lưu bước hợp lệ.");return;}
        if(lastRecognition.isEmpty()||lastRecognition.startsWith("Chưa nhận diện")||!lastRecognition.contains(label)){
            result.setText("Từ chối chạm: màn hình hiện tại chưa khớp '"+label+"'. Hãy chụp lại.");return;
        }
        // One explicit, user-triggered tap only. No loops or blind progression.
        result.setText("Đang thực hiện 1 chạm tại "+x+","+y);
        new Thread(()->{boolean ok=RootShell.tap(x,y);handler.post(()->{if(result!=null)result.setText(ok?"Đã gửi 1 thao tác chạm. Hãy kiểm tra game.":"Lệnh chạm thất bại; kiểm tra root.");});}).start();
    }
    private void stopEngine(){taskRunning=false;stopped=true;if(panel!=null){wm.removeView(panel);panel=null;}if(bubble!=null){wm.removeView(bubble);bubble=null;}stopForeground(STOP_FOREGROUND_REMOVE);}
    @Override public void onDestroy(){stopEngine();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
