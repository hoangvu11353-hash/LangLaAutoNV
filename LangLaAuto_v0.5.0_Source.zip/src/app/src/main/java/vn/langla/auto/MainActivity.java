package vn.langla.auto;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status,rootStatus,overlayStatus;
    private CheckBox daily,stages,boss,rewards,repeat;
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);render();}
    @Override protected void onResume(){super.onResume();if(overlayStatus!=null)overlayStatus.setText(Settings.canDrawOverlays(this)?"Quyền cửa sổ nổi: Đã cấp":"Quyền cửa sổ nổi: Chưa cấp");}
    private void render(){
        ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(18),dp(16),dp(24));root.setBackgroundColor(Color.rgb(245,247,250));sc.addView(root);setContentView(sc);
        TextView title=new TextView(this);title.setText("LÀNG LÁ AUTO");title.setTextSize(24);title.setTextColor(-1);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(18),0,dp(18));title.setBackgroundColor(Color.rgb(38,105,178));root.addView(title);
        status=text(root,"Trạng thái: Sẵn sàng",16);rootStatus=text(root,"Root: đang kiểm tra…",14);overlayStatus=text(root,"Quyền cửa sổ nổi: đang kiểm tra…",14);
        Button grant=button(root,"CẤP QUYỀN BONG BÓNG NỔI");grant.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));startActivity(i);}});
        text(root,"GAME",17);TextView pkg=text(root,"com.huyenthoailangla.gg",15);pkg.setTextIsSelectable(true);
        text(root,"CHỌN TÁC VỤ MUỐN THEO DÕI",17);
        daily=check(root,"Nhiệm vụ hằng ngày");rewards=check(root,"Nhận thưởng");stages=check(root,"Đi ải / chiến đấu");boss=check(root,"Thí luyện / Boss");repeat=check(root,"Lặp lại khi hoàn thành (chưa kích hoạt tự bấm)");
        Button start=button(root,"BẬT BONG BÓNG ĐIỀU KHIỂN");start.setOnClickListener(v->{
            if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"Hãy cấp quyền cửa sổ nổi trước",Toast.LENGTH_LONG).show();return;}
            Intent i=new Intent(this,AutomationService.class);i.setAction(AutomationService.ACTION_START);startForegroundService(i);status.setText("Trạng thái: Đang chạy bảng điều khiển nổi");
        });
        Button stop=button(root,"TẮT TOOL");stop.setOnClickListener(v->{Intent i=new Intent(this,AutomationService.class);i.setAction(AutomationService.ACTION_STOP);startService(i);status.setText("Trạng thái: Đã yêu cầu dừng");});
        text(root,"BẢN 0.5.0 – CHUỖI TÁC VỤ CÓ GIÁM SÁT",17);
        text(root,"• Bong bóng nổi LL kéo thả được.\n• Nhận diện theo 14 ảnh mẫu, chụp bằng root.\n• Tạo chuỗi riêng cho nhiệm vụ ngày, đi ải và nhận thưởng.\n• Mỗi bước có tên màn hình + tọa độ X/Y do bạn tự nhập.\n• Sau mỗi lần chạm, tool chụp lại và chỉ đi tiếp khi màn hình khớp chính xác.\n• Màn hình không khớp, ảnh sai kích thước hoặc lệnh lỗi: tự dừng, không chạm tiếp.\n• Có nút dừng khẩn cấp.",14);
        text(root,"Lưu ý: đây là APK source project; chưa phải bot tự động hoàn chỉnh. Các tọa độ không được cài sẵn vì chưa thể xác minh từ xa; người dùng phải ghi nhận từng nút trên máy thật trước khi chạy chuỗi.",13);
        new Thread(()->{boolean ok=RootShell.check();runOnUiThread(()->rootStatus.setText(ok?"Root: đã nhận uid=0":"Root: chưa cấp quyền su"));}).start();
    }
    private TextView text(LinearLayout l,String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.DKGRAY);t.setPadding(0,dp(9),0,dp(6));l.addView(t);return t;}
    private CheckBox check(LinearLayout l,String s){CheckBox c=new CheckBox(this);c.setText(s);c.setChecked(true);l.addView(c);return c;}
    private Button button(LinearLayout l,String s){Button b=new Button(this);b.setText(s);l.addView(b,new LinearLayout.LayoutParams(-1,-2));return b;}
}
