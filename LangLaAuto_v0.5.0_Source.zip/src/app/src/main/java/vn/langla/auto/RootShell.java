package vn.langla.auto;

import java.io.*;

public final class RootShell {
    private RootShell() {}
    public static boolean check() {
        try {
            Process p=new ProcessBuilder("su","-c","id").redirectErrorStream(true).start();
            BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line=r.readLine(); int code=p.waitFor();
            return code==0 && line!=null && line.contains("uid=0");
        } catch(Exception e){ return false; }
    }
    public static boolean command(String command) {
        try { Process p=new ProcessBuilder("su","-c",command).redirectErrorStream(true).start(); return p.waitFor()==0; }
        catch(Exception e){ return false; }
    }
    public static boolean tap(int x,int y){ return command("input tap "+Math.max(0,x)+" "+Math.max(0,y)); }
    public static boolean swipe(int x1,int y1,int x2,int y2,int ms){ return command("input swipe "+x1+" "+y1+" "+x2+" "+y2+" "+Math.max(80,ms)); }
    public static String capturePath(){
        // Root shell writes to its own stdout; app writes into its private storage.
        // This avoids SELinux issues caused by copying root-owned files into app data.
        File out=new File(System.getProperty("java.io.tmpdir"),"langla_screen.png");
        try {
            Process proc=new ProcessBuilder("su","-c","screencap -p").start();
            try(InputStream in=proc.getInputStream(); OutputStream dest=new FileOutputStream(out)){
                byte[] buf=new byte[32768]; int n;
                while((n=in.read(buf))!=-1)dest.write(buf,0,n);
            }
            int code=proc.waitFor();
            return code==0 && out.length()>1024 ? out.getAbsolutePath() : null;
        }catch(Exception e){return null;}
    }
}
