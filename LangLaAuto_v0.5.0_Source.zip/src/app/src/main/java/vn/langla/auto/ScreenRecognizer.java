package vn.langla.auto;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import java.io.InputStream;
import java.util.Locale;

/** Low-cost visual fingerprint matcher. A low-confidence result is always UNKNOWN. */
public final class ScreenRecognizer {
    public static final String[] FILES={
        "01_home.png","02_daily.png","03_challenge_map.png","04_training_boss.png",
        "05_stage_info.png","06_formation.png","07_survival_map.png","08_difficulty.png",
        "09_reward.png","10_chest_reward.png","11_support_buffs.png","12_ai_mode.png",
        "13_ai_stage_map_a.png","14_ai_stage_map_b.png"};
    public static final String[] LABELS={
        "Trang chủ","Nhiệm vụ ngày","Bản đồ Khiêu chiến","Thí luyện / Boss",
        "Thông tin ải","Đội hình","Thám hiểm Sinh Tồn","Chọn độ khó",
        "Nhận thưởng","Rương thưởng","Chọn trợ chiến","Chế độ Ải",
        "Bản đồ ải (nhánh A)","Bản đồ ải (nhánh B)"};
    private final Context context;
    public ScreenRecognizer(Context c){context=c.getApplicationContext();}
    private float[] feature(Bitmap src){
        Bitmap b=Bitmap.createScaledBitmap(src,12,6,true); float[] f=new float[12*6*3]; int k=0;
        for(int y=0;y<6;y++) for(int x=0;x<12;x++){
            int c=b.getPixel(x,y); f[k++]=Color.red(c)/255f; f[k++]=Color.green(c)/255f; f[k++]=Color.blue(c)/255f;
        }
        b.recycle(); return f;
    }
    public String recognize(Bitmap current){
        if(current==null)return "Không chụp được màn hình";
        float[] a=feature(current); float best=Float.MAX_VALUE, second=Float.MAX_VALUE; int idx=-1;
        for(int i=0;i<FILES.length;i++){
            try(InputStream in=context.getAssets().open("screen_profiles/"+FILES[i])){
                Bitmap t=BitmapFactory.decodeStream(in); if(t==null)continue;
                float[] b=feature(t); t.recycle(); float d=0;
                for(int j=0;j<a.length;j++) d+=Math.abs(a[j]-b[j]);
                d/=a.length; if(d<best){second=best;best=d;idx=i;}else if(d<second){second=d;}
            }catch(Exception ignored){}
        }
        // A deliberately conservative threshold; this is a hint, not authorization to tap.
        if(idx<0 || best>0.105f || second-best<0.012f) return String.format(Locale.US,"Chưa nhận diện chắc chắn (độ lệch %.3f)",best);
        return String.format(Locale.US,"%s (độ lệch %.3f, cách mẫu thứ hai %.3f)",LABELS[idx],best,second-best);
    }
}
