package vn.langla.auto;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** User-authored, screen-gated task sequences. No coordinates are guessed or bundled. */
public final class TaskEngine {
    public static final String DAILY="daily", STAGE="stage", REWARD="reward";
    public static final class Step {
        public final String screen; public final int x,y; public final long waitMs;
        Step(String s,int px,int py,long w){screen=s;x=px;y=py;waitMs=w;}
    }
    private final SharedPreferences prefs;
    public TaskEngine(Context c){prefs=c.getSharedPreferences("task_sequences_v1",Context.MODE_PRIVATE);}
    public synchronized boolean add(String task,String screen,int x,int y){
        if(!validTask(task)||screen==null||screen.trim().isEmpty()||x<0||x>=2400||y<0||y>=1080)return false;
        try{JSONArray a=new JSONArray(prefs.getString(task,"[]"));if(a.length()>=50)return false;
            JSONObject o=new JSONObject();o.put("screen",screen.trim());o.put("x",x);o.put("y",y);o.put("wait",2500);a.put(o);
            prefs.edit().putString(task,a.toString()).apply();return true;
        }catch(Exception e){return false;}
    }
    public synchronized List<Step> get(String task){
        List<Step> out=new ArrayList<>();if(!validTask(task))return out;
        try{JSONArray a=new JSONArray(prefs.getString(task,"[]"));for(int i=0;i<a.length();i++){
            JSONObject o=a.getJSONObject(i);out.add(new Step(o.getString("screen"),o.getInt("x"),o.getInt("y"),o.optLong("wait",2500)));
        }}catch(Exception ignored){}return out;
    }
    public synchronized void clear(String task){if(validTask(task))prefs.edit().remove(task).apply();}
    public static boolean validTask(String t){return DAILY.equals(t)||STAGE.equals(t)||REWARD.equals(t);}
    public static String title(String t){if(DAILY.equals(t))return "Nhiệm vụ ngày";if(STAGE.equals(t))return "Đi ải";return "Nhận thưởng";}
}
