# Làng Lá Auto v0.6.0 — Android source

Target game: Huyền Thoại Làng Lá (`com.huyenthoailangla.gg`).
Reference coordinate canvas: 2400 × 1080.
Supported Android versions: Android 6.0 (API 23) through Android 16 (API 36).

## Preserved features

- Three separately saved, user-authored sequences: daily tasks, stage runs, and reward collection.
- Each step stores the expected recognized screen label and an X/Y tap coordinate.
- A sequence takes a fresh screenshot before every tap and proceeds only if the recognized screen matches the expected label.
- Unknown or mismatched screens and failed root commands stop the sequence.
- Maximum 50 steps per sequence; emergency stop remains available.
- The 14 screen-profile images and existing saved sequences are retained.

## Compatibility updates in 0.6.0

- Minimum SDK lowered from API 26 to API 23 (Android 6.0).
- Foreground service startup is selected by Android version: `startService` on Android 6–7 and `startForegroundService` on Android 8+.
- Notification channels are created only on Android 8+; pre-O devices use the legacy notification builder.
- Android 13+ notification permission is requested without blocking a user-started foreground service if it is denied.
- Android 14+ starts the foreground service with the `specialUse` service type declared in the manifest.
- Screenshot files are written to the app-private cache instead of relying on `java.io.tmpdir`.
- Coordinates recorded on the 2400×1080 reference canvas are scaled to the actual captured screenshot dimensions.

## Important limitations

This is not a preconfigured game bot. The screenshots do not provide verified tap coordinates or a proven game-state transition graph. No coordinates are guessed or shipped. The user must inspect the live game and enter the correct expected screen label and pixel coordinate for each step. The 14-image color fingerprint matcher is approximate and can fail when the game has animations, popups, changed UI, or different rendering. Do not use this for paid purchases, spending premium currency, consuming rare items, or irreversible account actions. Test one step at a time first.

The project has not been built or run on a physical device as part of this source preparation. A successful GitHub Actions build is still required, followed by on-device testing.

## How to configure

1. Build and install the Android project. Grant overlay permission and approve `su` access.
2. Open the game in landscape mode and confirm that screen recognition identifies the current screen.
3. Open the LL bubble and press **CHỤP & NHẬN DIỆN**.
4. Enter the exact recognized screen name and the X/Y coordinate for one safe button on the 2400×1080 reference canvas.
5. Add that step to the relevant sequence: daily, stage, or reward.
6. Repeat for each transition, checking the screen label and coordinates at every stage.
7. Run only one sequence at a time. Watch the game during initial tests. Use **DỪNG KHẨN CẤP** if anything unexpected happens.

A task sequence follows only steps explicitly recorded by the user. If a screen does not match the expected label, the sequence stops without tapping.

## Build

Open this folder in Android Studio using Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, and Android SDK Platform 35 with targetSdk 34 for a conservative UI compatibility baseline. Build the `app` debug variant. The GitHub Actions workflow provided alongside this source installs these build dependencies automatically.
