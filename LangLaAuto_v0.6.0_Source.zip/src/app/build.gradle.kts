plugins { id("com.android.application") }

android {
    namespace = "vn.langla.auto"
    compileSdk = 35
    defaultConfig {
        applicationId = "vn.langla.auto"
        minSdk = 23
        targetSdk = 34
        versionCode = 6
        versionName = "0.6.0"
    }
}
