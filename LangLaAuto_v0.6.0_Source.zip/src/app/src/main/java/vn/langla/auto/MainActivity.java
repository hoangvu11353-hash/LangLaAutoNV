package vn.langla.auto;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView status, rootStatus, overlayStatus;
    private CheckBox daily, stages, boss, rewards, repeat;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + .5f);
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        render();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (overlayStatus != null) {
            overlayStatus.setText(Settings.canDrawOverlays(this)
                    ? "Quyền cửa sổ nổi: Đã cấp"
                    : "Quyền cửa sổ nổi: Chưa cấp");
        }
    }

    private void render() {
        ScrollView sc = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        sc.addView(root);
        setContentView(sc);

        TextView title = new TextView(this);
        title.setText("LÀNG LÁ AUTO");
        title.setTextSize(24);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(18), 0, dp(18));
        title.setBackgroundColor(Color.rgb(38, 105, 178));
        root.addView(title);

        status = text(root, "Trạng thái: Sẵn sàng", 16);
        rootStatus = text(root, "Root: đang kiểm tra…", 14);
        overlayStatus = text(root, "Quyền cửa sổ nổi: đang kiểm tra…", 14);

        Button grant = button(root, "CẤP QUYỀN BONG BÓNG NỔI");
        grant.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });

        text(root, "GAME", 17);
        TextView pkg = text(root, "com.huyenthoailangla.gg", 15);
        pkg.setTextIsSelectable(true);
        text(root, "CHỌN TÁC VỤ MUỐN THEO DÕI", 17);
        daily = check(root, "Nhiệm vụ hằng ngày");
        rewards = check(root, "Nhận thưởng");
        stages = check(root, "Đi ải / chiến đấu");
        boss = check(root, "Thí luyện / Boss");
        repeat = check(root, "Lặp lại khi hoàn thành (chưa kích hoạt tự bấm)");

        Button start = button(root, "BẬT BONG BÓNG ĐIỀU KHIỂN");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Hãy cấp quyền cửa sổ nổi trước", Toast.LENGTH_LONG).show();
                return;
            }
            // Android 13+: request notification permission, but do not block a user-started
            // foreground service if the user chooses not to grant it.
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 101);
            }
            Intent i = new Intent(this, AutomationService.class);
            i.setAction(AutomationService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            status.setText("Trạng thái: Đang chạy bảng điều khiển nổi");
        });

        Button stop = button(root, "TẮT TOOL");
        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, AutomationService.class);
            i.setAction(AutomationService.ACTION_STOP);
            startService(i);
            status.setText("Trạng thái: Đã yêu cầu dừng");
        });

        text(root, "BẢN 0.6.0 – TƯƠNG THÍCH ANDROID 6–16", 17);
        text(root, "• Giữ các chuỗi tác vụ ngày, đi ải và nhận thưởng đã lưu.\n"
                + "• Nhận diện theo 14 ảnh mẫu, chụp màn hình bằng root.\n"
                + "• Mỗi bước kiểm tra màn hình trước khi chạm; sai màn hình sẽ tự dừng.\n"
                + "• Tọa độ ghi theo khung 2400x1080 và tự co giãn theo ảnh màn hình thực tế.\n"
                + "• Hỗ trợ quyền thông báo Android 13+ và foreground service Android 14+.\n"
                + "• Có nút dừng khẩn cấp.", 14);
        text(root, "Lưu ý: tọa độ và thứ tự thao tác vẫn do bạn tự ghi nhận trên máy thật. "
                + "Hãy kiểm tra từng bước trước khi chạy chuỗi dài.", 13);

        new Thread(() -> {
            boolean ok = RootShell.check();
            runOnUiThread(() -> rootStatus.setText(ok
                    ? "Root: đã nhận uid=0"
                    : "Root: chưa cấp quyền su"));
        }).start();
    }

    private TextView text(LinearLayout l, String s, int z) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(z);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(0, dp(9), 0, dp(6));
        l.addView(t);
        return t;
    }

    private CheckBox check(LinearLayout l, String s) {
        CheckBox c = new CheckBox(this);
        c.setText(s);
        c.setChecked(true);
        l.addView(c);
        return c;
    }

    private Button button(LinearLayout l, String s) {
        Button b = new Button(this);
        b.setText(s);
        l.addView(b, new LinearLayout.LayoutParams(-1, -2));
        return b;
    }
}
