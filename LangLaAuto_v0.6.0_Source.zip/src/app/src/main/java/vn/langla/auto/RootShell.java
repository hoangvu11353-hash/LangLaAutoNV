package vn.langla.auto;

import android.content.Context;
import java.io.*;

public final class RootShell {
    private static final int REFERENCE_WIDTH = 2400;
    private static final int REFERENCE_HEIGHT = 1080;

    private RootShell() {}

    public static boolean check() {
        try {
            Process p = new ProcessBuilder("su", "-c", "id").redirectErrorStream(true).start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            int code = p.waitFor();
            return code == 0 && line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean command(String command) {
        try {
            Process p = new ProcessBuilder("su", "-c", command).redirectErrorStream(true).start();
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean tap(int x, int y) {
        return command("input tap " + Math.max(0, x) + " " + Math.max(0, y));
    }

    /** Convert coordinates recorded against the 2400x1080 reference canvas. */
    public static boolean tapScaled(int referenceX, int referenceY, int screenWidth, int screenHeight) {
        if (screenWidth <= 0 || screenHeight <= 0
                || referenceX < 0 || referenceX >= REFERENCE_WIDTH
                || referenceY < 0 || referenceY >= REFERENCE_HEIGHT) {
            return false;
        }
        int x = Math.round(referenceX * (screenWidth / (float) REFERENCE_WIDTH));
        int y = Math.round(referenceY * (screenHeight / (float) REFERENCE_HEIGHT));
        x = Math.min(screenWidth - 1, Math.max(0, x));
        y = Math.min(screenHeight - 1, Math.max(0, y));
        return tap(x, y);
    }

    public static boolean swipe(int x1, int y1, int x2, int y2, int ms) {
        return command("input swipe " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + Math.max(80, ms));
    }

    /** Capture to app-private cache; java.io.tmpdir is not reliable on Android. */
    public static String capturePath(Context context) {
        if (context == null) return null;
        File out = new File(context.getCacheDir(), "langla_screen.png");
        try {
            Process proc = new ProcessBuilder("su", "-c", "screencap -p").start();
            try (InputStream in = proc.getInputStream(); OutputStream dest = new FileOutputStream(out)) {
                byte[] buf = new byte[32768];
                int n;
                while ((n = in.read(buf)) != -1) dest.write(buf, 0, n);
                dest.flush();
            }
            int code = proc.waitFor();
            if (code == 0 && out.isFile() && out.length() > 1024) return out.getAbsolutePath();
        } catch (Exception ignored) {
            // A missing root grant or unsupported screencap command is reported to the UI.
        }
        // Do not leave a partial screenshot that could be mistaken for a valid capture.
        //noinspection ResultOfMethodCallIgnored
        out.delete();
        return null;
    }
}
